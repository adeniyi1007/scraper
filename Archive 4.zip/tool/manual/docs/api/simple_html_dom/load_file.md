# load_file

```php
load_file (...) : object
```

Loads a HTML document from file. Supports arguments of [`file_get_contents`](http://php.net/manual/en/function.file-get-contents.php).

Returns the object.