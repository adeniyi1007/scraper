# parentNode

```php
parentNode () : object
```

Returns the current's node parent.