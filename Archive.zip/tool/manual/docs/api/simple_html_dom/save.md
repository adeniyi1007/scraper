# save

```php
save ( [ string $filepath = '' ] ) : string
```

Writes the current DOM to file.

| Parameter     | Description
| ---------     | -----------
| `filepath`    | Writes to file if the provided file path is not empty.

Returns the document string.